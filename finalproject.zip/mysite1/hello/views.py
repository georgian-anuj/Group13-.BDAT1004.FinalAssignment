import requests
from django.shortcuts import render
from django.http import HttpResponse
from hello.models import MyModel,Weather
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from django.template import loader
import json

# Create your views here.
def index(request):

    return HttpResponse(request, 'home.html',{})


def about(request):

    return render(request, 'about.html',{})


def home(request):

    Weather.objects.all().delete()
    # set the WeatherAPI.com API key and the base URL
    api_key = "ca765a7f0e674ad8a2593436231904"
    base_url = "https://api.weatherapi.com/v1/history.json"

    # set the location and start date
    locations = ["barrie", "toronto","kitchener"]
    start_date = datetime.now() - timedelta(days=7)

    # format the start date and end date in the required format
    start_date_str = start_date.strftime("%Y-%m-%d")
    end_date_str = datetime.now().strftime("%Y-%m-%d")

    # set the query parameters
    params = {
        "key": api_key,
        "dt": start_date_str,
        "end_dt": end_date_str,
    }

    for location in locations:
        params["q"] = location

        # make the API call
        response = requests.get(base_url, params=params)

        # check if the request was successful
        if response.status_code == 200:
            # extract the weather data from the response
            data = json.loads(response.text)
            weather_data = data["forecast"]["forecastday"]
            for day in weather_data:
                data_load = Weather(city=location, date=day["date"],max_temp=day["day"]["maxtemp_c"],min_temp=day["day"]["mintemp_c"],avg_temp=day["day"]["avgtemp_c"],wind_speed=day["hour"][0]["wind_kph"],sunset=day["astro"]["sunset"],sunrise=day["astro"]["sunrise"],condition=day["day"]["condition"]["text"],feelslike_c=day["hour"][0]["feelslike_c"])
                data_load.save()
    return render(request, 'home.html', {})


def barrie(request,methods=['GET','POST']):
    data=Weather.objects.all()
    barrie_date = []
    barrie_max_temp = []
    barrie_min_temp = []
    barrie_avg_temp = []
    barrie_wind_speed = []
    barrie_sunset = []
    barrie_sunrise = []
    barrie_condition = []
    barrie_feelslike_c = []
    for raw in data:
        if raw.city=='barrie':
            barrie_date.append(raw.date)
            barrie_max_temp.append(raw.max_temp)
            barrie_min_temp.append(raw.min_temp)
            barrie_avg_temp.append(raw.avg_temp)
            barrie_wind_speed.append(raw.wind_speed)
            barrie_sunset.append(raw.sunset)
            barrie_sunrise.append(raw.sunrise)
            barrie_condition.append(raw.condition)
            barrie_feelslike_c.append(raw.feelslike_c)

    return render(request, 'barrie.html',{"barrie_date":barrie_date,"barrie_max_temp":barrie_max_temp,
    "barrie_min_temp":barrie_min_temp,"barrie_avg_temp":barrie_avg_temp,"barrie_wind_speed":barrie_wind_speed,"barrie_sunset":barrie_sunset,"barrie_sunrise":barrie_sunrise,
    "barrie_condition":barrie_condition,"barrie_feelslike_c":barrie_feelslike_c,"data":data
    })


def toronto(request,methods=['GET','POST']):
    data=Weather.objects.all()
    toronto_date = []
    toronto_max_temp = []
    toronto_min_temp = []
    toronto_avg_temp = []
    toronto_wind_speed = []
    toronto_sunset = []
    toronto_sunrise = []
    toronto_condition = []
    toronto_feelslike_c = []
    for raw in data:
        if raw.city=='toronto':
            toronto_date.append(raw.date)
            toronto_max_temp.append(raw.max_temp)
            toronto_min_temp.append(raw.min_temp)
            toronto_avg_temp.append(raw.avg_temp)
            toronto_wind_speed.append(raw.wind_speed)
            toronto_sunset.append(raw.sunset)
            toronto_sunrise.append(raw.sunrise)
            toronto_condition.append(raw.condition)
            toronto_feelslike_c.append(raw.feelslike_c)
    return render(request, 'toronto.html',{"toronto_date":toronto_date,"toronto_max_temp":toronto_max_temp,
    "toronto_min_temp":toronto_min_temp,"toronto_avg_temp":toronto_avg_temp,"toronto_wind_speed":toronto_wind_speed,"toronto_sunset":toronto_sunset,"toronto_sunrise":toronto_sunrise,
    "toronto_condition":toronto_condition,"toronto_feelslike_c":toronto_feelslike_c,"data":data
    })


def kitchner(request,methods=['GET','POST']):
    data=Weather.objects.all()
    kitchener_date = []
    kitchener_max_temp = []
    kitchener_min_temp = []
    kitchener_avg_temp = []
    kitchener_wind_speed = []
    kitchener_sunset = []
    kitchener_sunrise = []
    kitchener_condition = []
    kitchener_feelslike_c = []
    for raw in data:
        if raw.city=='kitchener':
            kitchener_date.append(raw.date)
            kitchener_max_temp.append(raw.max_temp)
            kitchener_min_temp.append(raw.min_temp)
            kitchener_avg_temp.append(raw.avg_temp)
            kitchener_wind_speed.append(raw.wind_speed)
            kitchener_sunset.append(raw.sunset)
            kitchener_sunrise.append(raw.sunrise)
            kitchener_condition.append(raw.condition)
            kitchener_feelslike_c.append(raw.feelslike_c)
    return render(request, 'kitchner.html',{"kitchener_date":kitchener_date,"kitchener_max_temp":kitchener_max_temp,
    "kitchener_min_temp":kitchener_min_temp,"kitchener_avg_temp":kitchener_avg_temp,"kitchener_wind_speed":kitchener_wind_speed,"kitchener_sunset":kitchener_sunset,"kitchener_sunrise":kitchener_sunrise,
    "kitchener_condition":kitchener_condition,"kitchener_feelslike_c":kitchener_feelslike_c,"data":data
    })

def weather_plot(request):
    api_key = "ca765a7f0e674ad8a2593436231904"
    base_url = "http://api.weatherapi.com/v1/history.json"

    # set the location and start date
    location = "Barrie"
    start_date = datetime.now() - timedelta(days=7)

    # create empty lists for dates and temperatures
    dates = []
    temps = []

    # loop through the past 7 days and make an API call for each day
    for i in range(7):
        date = start_date + timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        params = {"key": api_key, "q": location, "dt": date_str}
        response = requests.get(base_url, params=params)
        if response.status_code == 200:
            data = response.json()["forecast"]["forecastday"][0]["hour"]
            temps.append(sum([hour["temp_c"] for hour in data])/24)  # calculate daily average temperature
            dates.append(date.strftime("%d"))
            print(temps)
        else:
            print("Error: ", response.status_code)
    return render(request,"weather_plot.html", {"dates":dates,"temps":temps})




