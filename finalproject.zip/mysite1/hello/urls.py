from django.urls import path
from . import views


urlpatterns = [
    path('home/', views.index,name="index"),
    path('weather_plot/', views.weather_plot, name='weather_plot'),
    path('', views.home, name="home"),
    path('barrie/', views.barrie, name='barrie'),
    path('toronto/', views.toronto, name='toronto'),
    path('kitchner/', views.kitchner, name='kitchner'),
    path('about/',views.about,name='about')
    ]