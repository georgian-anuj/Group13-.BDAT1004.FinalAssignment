from django.db import models

# Create your models here.
class MyModel(models.Model):
    myfield = models.CharField(max_length=255)
    temp = models.CharField(max_length=200)


class Weather(models.Model):
    city = models.CharField(max_length=255)
    date = models.CharField(max_length=20) # assuming date is in YYYY-MM-DD format
    max_temp = models.CharField(max_length=10)
    min_temp = models.CharField(max_length=10)
    avg_temp = models.CharField(max_length=10)
    wind_speed = models.CharField(max_length=10)
    sunset = models.CharField(max_length=20)
    sunrise = models.CharField(max_length=20)
    condition = models.CharField(max_length=255)
    feelslike_c = models.CharField(max_length=30)
